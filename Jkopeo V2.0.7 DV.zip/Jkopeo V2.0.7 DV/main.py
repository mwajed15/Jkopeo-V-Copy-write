from tkinter import *
from Tool.Calaolater import create_calculator
from Tool.Note import create_Note
from Tool.ToDoList import creat_ToDo
from Tool.Bomodoro import create_Timer
from Sorce.Global import *
from Tool.Weekly_Calendar import *
#from ard.clickAD import *
from tkinter import filedialog
import webbrowser
import subprocess
import os
import sys
import threading
Main_form = Tk()

#-----------------------------------------| Image Lode && OS SYS |------------------------------------------------!#
def resource_path(relative_path): # --> TO Lode Image in Setup File
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


calcolater_IMG = PhotoImage(file=resource_path("Image/Button Icon/calcolatr-Button-ico.png"))
ToDO_IMG = PhotoImage(file=resource_path("Image/Button Icon/todolest-Button-Ico.png"))
Pomodoro_IMG = PhotoImage(file=resource_path("Image/Button Icon/Bomodoro-Button-Ico.png"))
Twiter_LOGO = PhotoImage(file=resource_path("Image/T_LoGo.png"))
Instgram_LOGO = PhotoImage(file=resource_path("Image/I_LoGo.png"))
Google_LOGO = PhotoImage(file=resource_path("Image/Gmail_loGo.png"))
Note_IMG = PhotoImage(file=resource_path("Image/Button Icon/notebook-Button-Ico.png"))
chatGPT_IMG = PhotoImage(file=resource_path("Image/Button Icon/chatgpt-Button-Ico.png"))
Sarch_Icone = PhotoImage(file=resource_path("Image/Sarch-Icon.png"))
Google_lio = PhotoImage(file=resource_path("Image/Google-icon-UB.png"))
Week_ca_IMG = PhotoImage(file=resource_path("Image/Button Icon/weekly_calendar.png"))
Youtup_IMG = PhotoImage(file=resource_path("Image/Button Icon/YOUTUp_LOgo.png"))
focas_IMG = PhotoImage(file=resource_path("Image/Button Icon/No Notifications.png"))
#YourTODO = PhotoImage(file=resource_path("Image/Your ToDo List.png"))


#-----------------------------------------| Main Form Option  |-----------------------------------------------------!#
Main_form.geometry("1024x600+180+40") #? --> Hight and Wight of Windos
Main_form.resizable(False, False) #? --> Hide The Maxmain Button
Main_form.title("JKobeo") #? --> Titel of Program
Main_form.config(bg="#D3D3D3",relief="flat") #? --> Option 

leb_Left = Label(Main_form, bg="#607D8B", font=("arial", 12))
leb_Left.place(x=0, y=0, width=200, height=700)

Name_Lab = Label(Main_form, text="",font=("arial", 18),)
Name_Lab = Label(Main_form, text="",font=("arial", 18),bg = "#D3D3D3")
Name_Lab.place(x=220,y=10)

#-----------------------------------------| Import and Open the Def |------------------------------------------------!#

# Forms
def open_note(): #? -- Enable Note Form 
    create_Note()
def open_calculator(): #? -- Enable Calculator Form 
    create_calculator()
def open_Todo(): #? -- Enable Todo Lest Form 
    creat_ToDo()
def open_Timer(): #? Enable Timer/Bomodoro Form 
    create_Timer()
def open_wikk_calender():
    create_weekly_calendar()
def enable_focas_mode():
    subprocess.run(["powershell", "New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings' -Name 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' -Value 0 -Force"], shell=True)
    subprocess.run(["powershell", "New-ItemProperty -Path 'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings' -Name 'NOC_GLOBAL_SETTING_DO_NOT_DISTURB' -Value 1 -Force"], shell=True)

# Website
def open_ChatGPT(): #? Enable chatGPT WEB
    webbrowser.open("https://chatgpt.com")
def Open_insta(): #? Open Instgram WEB
    webbrowser.open("https://www.instagram.com/mwwaajeddd/") 
def Open_Twiter(): #? Open Twiter WEB
    webbrowser.open("https://x.com/scorfar58100") 
def Open_Google(): #? Open Googlr WEB 
    webbrowser.open("https://mail.google.com")
def click_JK_Logo():
    webbrowser.open("https://jkopeo.odoo.com")
def Oppen_Youtop():
    webbrowser.open("https://www.youtube.com")


#-----------------------------------------| All thinks abuot Home Button|-----------------------------------------------!#
def click_Home():
    global Support_button_label, Home_Button_lapal, Search_button_label 

    if Support_button_label: Support_button_label.place_forget()
    if Search_button_label: Search_button_label.place_forget()

    Home_Button_lapal = Label(Main_form, bg="#D3D3D3")
    Home_Button_lapal.place(y=0, x=200, height=650, width=824)
    
    # Calculator Button
    calolat_But = Button(Home_Button_lapal, image=calcolater_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_calculator)
    calolat_But.place(x=650-5, y=10, width=170, height=170)

    # Note Button
    Note_Button = Button(Home_Button_lapal, image=Note_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_note)
    Note_Button.place(x=490-5, y=10, width=175, height=170)

    # To Do List Button
    ToDO_Button = Button(Home_Button_lapal, image=ToDO_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_Todo)
    ToDO_Button.place(x=330-5, y=10, width=170, height=170)

    # Chat GPT Button
    chatGPT_Button = Button(Home_Button_lapal, image=chatGPT_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_ChatGPT)
    chatGPT_Button.place(x=170-5, y=10, width=170, height=170)

    # Pomodoro Timer Button
    Pomodoro_Button = Button(Home_Button_lapal, image=Pomodoro_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_Timer)
    Pomodoro_Button.place(x=10-5, y=10, width=170, height=170)

    # Weekly_calender button
    Weekly_calendr = Button(Home_Button_lapal, image=Week_ca_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=open_wikk_calender)
    Weekly_calendr.place(x=330-5, y=175, width=170, height=170)

    # Youtup Button
    Youtup_button = Button(Home_Button_lapal, image=Youtup_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=Oppen_Youtop)
    Youtup_button.place(x=170-5, y=175, width=170, height=170)

    # Focas button
    Youtup_button = Button(Home_Button_lapal, image=focas_IMG, relief="flat", bg="#D3D3D3", bd=0, activebackground="#D3D3D3", command=enable_focas_mode)
    Youtup_button.place(x=10-5, y=175, width=170, height=170)

    back_todo = Label(Home_Button_lapal)
    back_todo.place(x=522,y=205-20,width=260,height=250)
    back_TOTX = Label(Home_Button_lapal,text="Your To Do List :)",font=("arial",9))
    back_TOTX.place(x=600,y=207-20)

    def load_tasks_from_file():
        tasks = []
        try:
            with open("tasks.txt", "r") as f:
                tasks = f.readlines()
                tasks = [task.strip() for task in tasks]
        except FileNotFoundError:
            print("ERROR: File not found")
        return tasks

    def display_tasks(tasks):
        task_listbox = Listbox(Home_Button_lapal, width=40-10, height=14-2, relief="flat", bg="gray", fg="#000000",font=("arial", 11))  # White background, Black text
        task_listbox.place(x=530,y=225-20)
        for task in tasks:
            task_listbox.insert(END, task)  # Add tasks in order they are read

    tasks = load_tasks_from_file()
    display_tasks(tasks)



#-----------------------------------------| All thinks abuot About Us Button|----------------------------------------------!#

def click_AbuotUs():

    # Global Import From Sores.Global.py   
    global Support_button_label,Home_Button_lapal,Search_button_label 

    if Home_Button_lapal: Home_Button_lapal.place_forget()
    if Search_button_label : Search_button_label.place_forget()


    Support_button_label = Label(Main_form, bg="#D3D3D3")
    Support_button_label.place(y=0,x=200,height=650,width=824)

    # Instgram Button
    Instgram_Button = Button(Support_button_label, image=Instgram_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_insta)
    Instgram_Button.place(x=120, y=110, width=90, height=90)
    Instgram_Text = Label(Support_button_label, text=" OR  --> https://www.instagram.com/mwwaajeddd/")
    Instgram_Text.place(x=220, y=145)

    # Twiter Button
    Titer_Button = Button(Support_button_label, image=Twiter_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_Twiter)
    Titer_Button.place(x=120, y=185, width=90, height=90)
    Titer_Text = Label(Support_button_label, text=" OR  --> https://x.com/scorfar58100")
    Titer_Text.place(x=220, y=220)

    # Google Button
    Google_Button = Button(Support_button_label, image=Google_LOGO, bg="#D3D3D3", relief="flat", activebackground="#D3D3D3", bd=0, command=Open_Google)
    Google_Button.place(x=120, y=260, width=90, height=90)
    Google_Text = Label(Support_button_label, text=" OR  --> mareano15s@gmail.com")
    Google_Text.place(x=220, y=295)

    # Panel Support Such Media
    suport_panal = Label(Support_button_label, text="Suport", bg="gray", fg="#F5F5DC", font=("arial", 12))
    suport_panal.place(x=120, y=100, width=600, height=20)


#-----------------------------------------| All thinks abuot Sarch Button|-----------------------------------------------!#
def click_Sarch():

    # Global Import From Sores.Global.py
    global Support_button_label,Home_Button_lapal,Search_button_label 

    if Home_Button_lapal: Home_Button_lapal.place_forget()
    if Support_button_label: Support_button_label.place_forget

    # TO Hide all page withot sport]
    Search_button_label = Label(Main_form, bg="#D3D3D3")
    Search_button_label.place(y=0,x=200,height=650,width=824)


    # sarch on Google
    def Serch_Gogle():
        query = Sarch_entre.get()
        search_url = f"https://www.google.com/search?q={query}"
        webbrowser.open(search_url)

    # Google banal
    Google_Icon = Button(Search_button_label,image=Google_lio,relief="flat",bd=0,bg="#D3D3D3")
    Google_Icon.place(x=270,y=130)

    # Sarch Batton 
    Serch_button = Button(Search_button_label, image=Sarch_Icone,relief="flat",bd=0,command=Serch_Gogle)
    Serch_button.place(x=120, y=295)

    # Serch Bar
    Sarch_entre = Entry(Search_button_label, width=60,relief="flat",font=("arial", 13))
    Sarch_entre.place(x=170,y=300,height=30)


#-----------------------------------------| All Button in main Form|-----------------------------------------------!#

# Home Button
Home_Im = PhotoImage(file=resource_path("Image/ButtonTX/Home.png"))
But1 = Button(Main_form,image=Home_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_Home,bg="#DAD9D6")
But1.place(x=30, y=140, width=130, height=40)

# Sarch Button
search_Im = PhotoImage(file=resource_path("Image/ButtonTX/Sarche.png"))
But2 = Button(Main_form,image=search_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_Sarch,bg="#DAD9D6")
But2.place(x=30, y=210, width=130, height=35)

# About Us Button
Support_Im = PhotoImage(file=resource_path("Image/ButtonTX/Support.png"))
But3 = Button(Main_form,image=Support_Im, activebackground="#ADD8E6", relief="flat", bd=0.1, command=click_AbuotUs)
But3.place(x=30, y=275, width=130, height=35.5)

# Jk Oprion
Jk_icon = PhotoImage(file=resource_path("Image/ButtonTX/Jk.png"))
but4 = Button(Main_form,image=Jk_icon,bd=0,bg="#DAD9D6",activebackground="#ADD8E6",command=click_JK_Logo)
but4.place(x=52,y=15,width=80,height=90)

#-----------------------------AD--------------------------------------------------------------------


click_Home()
Main_form.mainloop()
