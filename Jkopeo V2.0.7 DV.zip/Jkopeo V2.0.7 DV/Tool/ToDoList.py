import os
from tkinter import *

# تحديد مسار مجلد المستندات الخاص بالمستخدم
def get_save_path():
    user_folder = os.path.expanduser("~")
    return os.path.join(user_folder, "Documents")

def creat_ToDo():
    ToDO_Windos = Toplevel()  # استخدام Toplevel بدلاً من Tk
    ToDO_Windos.geometry("400x500")
    ToDO_Windos.title("To Do List - Jk")
    ToDO_Windos.config(bg="#D3D3D3")

    def add_task():
        task = task_Entry.get()
        if task:
            todo_task_list.insert(0, task)
            task_Entry.delete(0, END)
            save_tasks()
        else:
            print("ERROR: No task entered")
            
    def remove_task():
        selected = todo_task_list.curselection()
        if selected:
            todo_task_list.delete(selected[0])
            save_tasks()
        else:
            print("ERROR: No task selected")
    
    def save_tasks():
        # تحديد المسار الآمن لحفظ الملف في مجلد "Documents"
        save_path = os.path.join(get_save_path(), "tasks.txt")
        with open(save_path, "w") as f:
            tasks = todo_task_list.get(0, END)
            for task in tasks:
                f.write(task + "\n")
    
    def load_tasks():
        # تحديد المسار الآمن لتحميل الملف من مجلد "Documents"
        save_path = os.path.join(get_save_path(), "tasks.txt")
        try:
            with open(save_path, "r") as f:
                tasks = f.readlines()
                for task in tasks:
                    todo_task_list.insert(0, task.strip())
        except FileNotFoundError:
            print("ERROR: File not found")

    Add_button = Button(ToDO_Windos, command=add_task, bg="#61AFEF", text="Add", activebackground="#ADD8E6", relief="flat", bd=0.1)
    Add_button.place(x=50, y=100, width=130, height=30)

    Remove_button = Button(ToDO_Windos, command=remove_task, bg="#61AFEF", text="Remove", activebackground="#ADD8E6", relief="flat", bd=0.1)
    Remove_button.place(x=220, y=100, width=130, height=30)

    task_Entry = Entry(ToDO_Windos, relief="flat", bg="gray")
    task_Entry.place(x=40, y=40, width=320, height=30)

    todo_task_list = Listbox(ToDO_Windos, width=49, height=18, relief="flat", bg="gray")
    todo_task_list.place(x=50, y=150)

    load_tasks()
