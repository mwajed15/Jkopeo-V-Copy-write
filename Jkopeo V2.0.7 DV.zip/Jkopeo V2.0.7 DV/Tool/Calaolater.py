import tkinter as tk

def create_calculator():
    def click_button(value):
        current_text = entry.get()
        entry.delete(0, tk.END)
        entry.insert(tk.END, current_text + str(value))

    def clear_entry():
        entry.delete(0, tk.END)

    def calculate():
        try:
            result = eval(entry.get())
            entry.delete(0, tk.END)
            entry.insert(tk.END, result)
        except Exception:
            entry.delete(0, tk.END)
            entry.insert(tk.END, "Error")
    
    calc_window = tk.Toplevel()
    calc_window.title("Calculator - Jk")
    calc_window.resizable(False,False)
    calc_window.geometry("300x280")
    calc_window.configure(bg="#D3D3D3")

    entry = tk.Entry(calc_window, font=("Arial", 18), borderwidth=2, relief="groove", justify="right", bg="#61AFEF", fg="#282C34")
    entry.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

    buttons = [
        ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
        ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
        ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
        ('C', 4, 0), ('0', 4, 1), ('=', 4, 2), ('+', 4, 3),
    ]

    for (text, row, col) in buttons:
        btn = tk.Button(
            calc_window, text=text, command=(calculate if text == '=' else (clear_entry if text == 'C' else lambda val=text: click_button(val))),
            height=1, width=5, font=("Arial", 14),
            bg="#61AFEF" if text in ['+', '-', '*', '/'] else "#D3D3D3",
            fg="#282C34",
            activebackground="#C678DD",
            activeforeground="#FFFFFF",
            relief="flat"
        )
        btn.grid(row=row, column=col, padx=5, pady=5)
