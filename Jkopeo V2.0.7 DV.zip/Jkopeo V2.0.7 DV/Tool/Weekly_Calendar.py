import os
from tkinter import *

# تعديل مسار حفظ الملفات
def get_save_path():
    # الحصول على مسار مجلد المستخدم
    user_folder = os.path.expanduser("~")
    # حفظ الملف داخل مجلد Documents
    return os.path.join(user_folder, "Documents", "Weekly_Tasks.txt")

def save_all_tasks(sunday_list, monday_list, tuesday_list, wednesday_list, thursday_list, friday_list, saturday_list):
    # حفظ جميع المهام في ملف واحد مع فصل المهام لكل يوم
    with open(get_save_path(), "w") as file:
        file.write("Sunday:\n")
        file.write(sunday_list.get("1.0", END).strip() + "\n\n")
        file.write("Monday:\n")
        file.write(monday_list.get("1.0", END).strip() + "\n\n")
        file.write("Tuesday:\n")
        file.write(tuesday_list.get("1.0", END).strip() + "\n\n")
        file.write("Wednesday:\n")
        file.write(wednesday_list.get("1.0", END).strip() + "\n\n")
        file.write("Thursday:\n")
        file.write(thursday_list.get("1.0", END).strip() + "\n\n")
        file.write("Friday:\n")
        file.write(friday_list.get("1.0", END).strip() + "\n\n")
        file.write("Saturday:\n")
        file.write(saturday_list.get("1.0", END).strip() + "\n\n")

def load_all_tasks(sunday_list, monday_list, tuesday_list, wednesday_list, thursday_list, friday_list, saturday_list):
    # تحميل جميع المهام من ملف واحد
    try:
        with open(get_save_path(), "r") as file:
            content = file.read()
            days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
            tasks = content.split("\n\n")
            
            for i, day in enumerate(days):
                if i < len(tasks):
                    start_idx = tasks[i].find(day) + len(day) + 1
                    end_idx = tasks[i].find("\n\n", start_idx)
                    if end_idx == -1:
                        end_idx = len(tasks[i])
                    task_text = tasks[i][start_idx:end_idx].strip()
                    
                    if day == "Sunday":
                        sunday_list.delete("1.0", END)
                        sunday_list.insert("1.0", task_text)
                    elif day == "Monday":
                        monday_list.delete("1.0", END)
                        monday_list.insert("1.0", task_text)
                    elif day == "Tuesday":
                        tuesday_list.delete("1.0", END)
                        tuesday_list.insert("1.0", task_text)
                    elif day == "Wednesday":
                        wednesday_list.delete("1.0", END)
                        wednesday_list.insert("1.0", task_text)
                    elif day == "Thursday":
                        thursday_list.delete("1.0", END)
                        thursday_list.insert("1.0", task_text)
                    elif day == "Friday":
                        friday_list.delete("1.0", END)
                        friday_list.insert("1.0", task_text)
                    elif day == "Saturday":
                        saturday_list.delete("1.0", END)
                        saturday_list.insert("1.0", task_text)
    except FileNotFoundError:
        pass

def create_weekly_calendar():
    Weekly_Calendar = Toplevel()
    Weekly_Calendar.geometry("800x500")
    Weekly_Calendar.title("TO DO IN WEEK")
    Weekly_Calendar.config(bg="#D3D3D3")

    top_l = Label(Weekly_Calendar, text="Your Weekly Calendar", font=("arial", 20))
    top_l.place(x=250, y=10)

    sun_T = Label(Weekly_Calendar, text="Sunday", bg="#607D8B", font=("arial", 11))
    sun_T.place(x=95, y=70)

    sunday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    sunday_list.place(x=90, y=90)

    mon_T = Label(Weekly_Calendar, text="Monday", bg="#607D8B", font=("arial", 11))
    mon_T.place(x=255, y=70)

    monday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    monday_list.place(x=250, y=90)

    tus_T = Label(Weekly_Calendar, text="Tuesday", bg="#607D8B", font=("arial", 11))
    tus_T.place(x=415, y=70)

    tuesday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    tuesday_list.place(x=410, y=90)

    wens_T = Label(Weekly_Calendar, text="Wednesday", bg="#607D8B", font=("arial", 11))
    wens_T.place(x=575, y=70)

    wednesday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    wednesday_list.place(x=570, y=90)

    thurs_T = Label(Weekly_Calendar, text="Thursday", bg="#607D8B", font=("arial", 11))
    thurs_T.place(x=200, y=270)

    thursday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    thursday_list.place(x=195, y=290)

    fri_T = Label(Weekly_Calendar, text="Friday", bg="#607D8B", font=("arial", 11))
    fri_T.place(x=360, y=270)

    friday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    friday_list.place(x=355, y=290)

    sat_T = Label(Weekly_Calendar, text="Saturday", bg="#607D8B", font=("arial", 11))
    sat_T.place(x=520, y=270)

    saturday_list = Text(Weekly_Calendar, width=20, height=10, font=("arial", 10), bg="gray")
    saturday_list.place(x=515, y=290)

    load_all_tasks(sunday_list, monday_list, tuesday_list, wednesday_list, thursday_list, friday_list, saturday_list)

    def on_close():
        save_all_tasks(sunday_list, monday_list, tuesday_list, wednesday_list, thursday_list, friday_list, saturday_list)
        Weekly_Calendar.destroy()

    Weekly_Calendar.protocol("WM_DELETE_WINDOW", on_close)
