from tkinter import *
from tkinter import filedialog

def create_Note():
    note_Windos = Tk()
    note_Windos.title("Note - JK")
    note_Windos.geometry("600x480")
    note_Windos.config(bg="#D3D3D3")

    Text_Boxe = Text(note_Windos, bg="gray", width=73, height=26.5, fg="#F5F5DC")
    Text_Boxe.place(x=6, y=40)

    status_label = Label(note_Windos, text="",bg="#282C34",fg="#F5F5DC")
    status_label.place(x=550,y=10)
    
    def save_file():
        fill_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if fill_path:
            text_to_save = Text_Boxe.get(1.0, END).rstrip()
            with open(fill_path, "w", encoding="utf-8") as file:
                file.write(text_to_save)
        status_label.config(text="Saved :)")
        note_Windos.after(2000,lambda: status_label.config(text="",width=0))
    
    def copy_file():
        COp = Text_Boxe.get(1.0, END).strip()
        note_Windos.clipboard_clear()
        note_Windos.clipboard_append(COp)
        status_label.config(text="Copy :)")
        note_Windos.after(2000, lambda: status_label.config(text=""))

    Save_button = Button(note_Windos, bg="#61AFEF", text="Save", activebackground="#ADD8E6", relief="flat", bd=0.1, command=save_file)
    Save_button.place(x=10, y=10)

    coby_button = Button(note_Windos, bg="#61AFEF", text="Coby", activebackground="#ADD8E6", relief="flat", bd=0.1, command=copy_file)
    coby_button.place(x=50, y=10)

    note_Windos.mainloop()
