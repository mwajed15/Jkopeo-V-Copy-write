from tkinter import *
import threading
import time
import webbrowser

def show_reminder():
    reminder_window = Tk()
    reminder_window.title("تذكير")
    reminder_window.geometry("445x200+500+200")
    reminder_window.config(bg="#607D8B")
    reminder_window.overrideredirect(True)

    # دالة لفتح الرابط
    def open_click():
        webbrowser.open("https://ouo.io/NUiOv3")
        reminder_window.destroy()  # تدمير النافذة بعد فتح الرابط

    Donach = Label(reminder_window, text="❤❤❤", font=("arial", 20), bg="#DAD9D6")
    Donach.pack(pady=10)

    label = Label(reminder_window, font=("arial", 11), 
                  text="Sorry for the inconvenience \n You can support Jkopeo completely for free by watching a short ad",
                  bg="#DAD9D6")
    label.place(x=2, y=70)

    # زر لفتح الرابط
    button = Button(reminder_window, text="Watch Ad", command=open_click, relief="ridge", bg="#DAD9D6")
    button.place(x=400-30, y=140, width=70, height=40)

    reminder_window.mainloop()

def start_timer():
    time.sleep(1800000)  # تمثيل مؤقت 10 ثوانٍ لتجربة
    show_reminder()

# بدء المؤقت في خيط مستقل
threading.Thread(target=start_timer, daemon=True).start()
