from tkinter import *

# the Globals
Search_button_label = None
Support_button_label = None
Home_Button_lapal = None